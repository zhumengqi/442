function new_img = stich_images(img1, img2)

	% Return a new complete image that stitches the two input images together
	% If the two images cannot be stitched together, return 0

end