function new_img = stitch_multiple_images(imgs)

	% Given a set of images in any order, stitch them together into a final panorama
	% Example call: stitch_multiple_images({img1, img2, img3})

end