brief introduction:
to get the figures of stitching two pages, run ZMQ_stitch_two_pages.m;
to get the figures of stitching three images, run ZMQ_stitch_three_pages.m.